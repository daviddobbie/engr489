# flint
Fast algorithms for estimation of NMR relaxation
